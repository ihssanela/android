package com.example.quizapp

object setData {

    const val name:String="name"
    const val score:String="score"

   fun getQuestion():ArrayList<QuestionData>{
       var que:ArrayList<QuestionData> = arrayListOf()

       var question1 = QuestionData(
           1,
           "Qu'est-ce que Kotlin ?",

           "Un langage de balisage pour les pages web",
           "Un outil de développement web",
           "Un système d'exploitation pour smartphones",
           "Un langage de programmation basé sur Java",
           4
       )
       var question2 = QuestionData(
           2,
           "Quelle est la principale caractéristique de Kotlin ?",

           " Il prend en charge la programmation fonctionnelle",
           " Il est strictement orienté objet",
           " Il est conçu spécifiquement pour les jeux vidéo",
           " Il est entièrement compatible avec le langage C",
           1
       )
       var question3 = QuestionData(
           3,
           "Quelle est la syntaxe de base utilisée pour déclarer une fonction en Kotlin ?",

           " function myFunction() {}",
           "fun myFunction() {}",
           " def myFunction() {}",
           "void myFunction() {}",
           2
       )
       var question4 = QuestionData(
           4,
           "Quelle est l'utilisation principale de l'expression _when_ en Kotlin ?",

           "Pour créer des boucles infinies",
           "Pour déclarer des fonctions récursives",
           "Pour effectuer une correspondance de motifs",
           "Pour gérer les exceptions",
           3
       )

       var question5 = QuestionData(
           5,
           "Comment déclare-t-on une classe en Kotlin ?",

           "def MyClass {}",
           "new class MyClass {}",
           " class = MyClass {}",
           "class MyClass {}",
           4
       )

       que.add(question1)
       que.add(question2)
       que.add(question3)
       que.add(question4)
       que.add(question5)
       return que
   }
}